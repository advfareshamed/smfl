#include <SFML/Graphics.hpp>
int main()
{

}
